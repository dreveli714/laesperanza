/**********************************************************************
 *  FINCA LA ESPERANZA — Google Apps Script (backend)
 *
 *  QUÉ HACE:
 *   - Recibe datos de la app (doPost) y los guarda en el Google Sheet.
 *   - Entrega los datos a la app (doGet).
 *   - Crea las pestañas y columnas solas según los datos que llegan.
 *   - Sube fotos a Google Drive y devuelve un enlace de miniatura.
 *   - Filtra por un TOKEN secreto (para que nadie más entre).
 *
 *  CÓMO INSTALAR:
 *   1. Abre tu Google Sheet.
 *   2. Menú: Extensiones → Apps Script.
 *   3. Borra todo lo que haya y pega ESTE código completo.
 *   4. Cambia el TOKEN de abajo por una clave tuya (o deja "esperanza2026").
 *   5. Guarda (💾).
 *   6. Botón "Implementar" → "Administrar implementaciones".
 *      - Si YA tienes una, toca el lápiz ✏️ → Versión: "Nueva versión" → Implementar.
 *        (Así la URL sigue siendo la misma).
 *      - Si NO tienes, "Nueva implementación" → Aplicación web →
 *        Ejecutar como: "Yo", Quién tiene acceso: "Cualquier usuario" → Implementar.
 *   7. Copia la URL (termina en /exec).
 *   8. En la app: Más → Ajustes → pega esa URL y el mismo TOKEN → Recargar datos.
 **********************************************************************/

// ⚠️ CAMBIA ESTO por tu clave secreta (la misma que pondrás en la app)
var TOKEN = 'esperanza2026';

// Carpeta de Drive donde se guardan las fotos (se crea sola)
var CARPETA_FOTOS = 'Finca La Esperanza - Fotos';

// Mapa: nombre interno de la app  →  nombre de la pestaña en el Sheet
// (Diana tiene las pestañas con mayúscula: Registros, Caja, Leche…)
var TABLAS = {
  registros:    'Registros',
  produccion:   'Produccion',
  animales:     'Animales',
  leche:        'Leche',
  salud:        'Salud',
  inventario:   'Inventario',
  caja:         'Caja',
  galeria:      'Galeria',
  planificador: 'Planificador'
};


// ════════════════════════════════════════════════════════════
//  RECIBIR DATOS DE LA APP (guardar)
// ════════════════════════════════════════════════════════════
function doPost(e) {
  try {
    var body = JSON.parse(e.postData.contents);
    if (body.token !== TOKEN) return json({ ok: false, error: 'Token inválido' });

    var tabla = body.tabla || 'registros';
    var reg = body.registro || {};

    // Si viene una foto (base64), subirla a Drive
    if (body.foto && body.foto.data) {
      try {
        var url = subirFoto(body.foto.data, body.foto.nombre || ('foto_' + Date.now()));
        reg.fotoUrl = url;
        reg.comprobanteUrl = url;
      } catch (err) {
        // La foto falla pero el dato se guarda igual (nunca bloquea)
      }
    }

    // Sello del servidor (clave para sincronizar bien)
    reg.recibido = Date.now();

    guardarFila(tabla, reg);

    return json({ ok: true, recibido: reg.recibido, fotoUrl: reg.fotoUrl || '' });
  } catch (err) {
    return json({ ok: false, error: String(err) });
  }
}


// ════════════════════════════════════════════════════════════
//  ENTREGAR DATOS A LA APP (bajar)
// ════════════════════════════════════════════════════════════
function doGet(e) {
  try {
    var token = e.parameter.token;
    if (token !== TOKEN) return json({ ok: false, error: 'Token inválido' });

    var desde = e.parameter.desde ? Number(e.parameter.desde) : 0;
    var ss = SpreadsheetApp.getActiveSpreadsheet();
    var datos = {};

    // Recorre el mapa: la app pide 'registros' pero leemos la pestaña 'Registros'
    Object.keys(TABLAS).forEach(function (claveApp) {
      var nombreHoja = TABLAS[claveApp];
      var hoja = buscarHoja(ss, nombreHoja);
      datos[claveApp] = hoja ? leerHoja(hoja, desde) : [];
    });

    return json({ ok: true, servidor: Date.now(), datos: datos });
  } catch (err) {
    return json({ ok: false, error: String(err) });
  }
}


// Busca la pestaña sin importar mayúsculas/minúsculas
function buscarHoja(ss, nombre) {
  var hoja = ss.getSheetByName(nombre);
  if (hoja) return hoja;
  // Fallback: buscar sin distinguir mayúsculas
  var hojas = ss.getSheets();
  for (var i = 0; i < hojas.length; i++) {
    if (hojas[i].getName().toLowerCase() === nombre.toLowerCase()) return hojas[i];
  }
  return null;
}


// ════════════════════════════════════════════════════════════
//  GUARDAR UNA FILA (crea pestaña y columnas si no existen)
// ════════════════════════════════════════════════════════════
function guardarFila(claveApp, reg) {
  var ss = SpreadsheetApp.getActiveSpreadsheet();
  var nombreHoja = TABLAS[claveApp] || claveApp;
  var hoja = buscarHoja(ss, nombreHoja);
  if (!hoja) hoja = ss.insertSheet(nombreHoja);

  // Encabezados actuales
  var lastCol = hoja.getLastColumn();
  var headers = lastCol > 0 ? hoja.getRange(1, 1, 1, lastCol).getValues()[0] : [];

  // Agregar columnas nuevas que traiga el registro
  var keys = Object.keys(reg);
  keys.forEach(function (k) {
    if (headers.indexOf(k) === -1) {
      headers.push(k);
      hoja.getRange(1, headers.length).setValue(k);
    }
  });

  // ¿Ya existe una fila con este id? → actualizar; si no → agregar
  var idCol = headers.indexOf('id');
  var fila = -1;
  if (idCol !== -1 && hoja.getLastRow() > 1) {
    var ids = hoja.getRange(2, idCol + 1, hoja.getLastRow() - 1, 1).getValues();
    for (var i = 0; i < ids.length; i++) {
      if (String(ids[i][0]) === String(reg.id)) { fila = i + 2; break; }
    }
  }

  // Armar la fila en el orden de los headers
  var valores = headers.map(function (h) {
    return reg[h] !== undefined && reg[h] !== null ? reg[h] : '';
  });

  if (fila === -1) {
    hoja.appendRow(valores);
  } else {
    hoja.getRange(fila, 1, 1, valores.length).setValues([valores]);
  }
}


// ════════════════════════════════════════════════════════════
//  LEER UNA HOJA (con filtro incremental por 'recibido')
// ════════════════════════════════════════════════════════════
function leerHoja(hoja, desde) {
  if (hoja.getLastRow() < 2) return [];
  var rango = hoja.getDataRange().getValues();
  var headers = rango[0];
  var recibidoCol = headers.indexOf('recibido');
  var filas = [];

  for (var i = 1; i < rango.length; i++) {
    var fila = rango[i];
    // Filtro incremental: solo los que llegaron después de 'desde'
    if (desde && recibidoCol !== -1) {
      var rec = Number(fila[recibidoCol]) || 0;
      if (rec <= desde) continue;
    }
    var obj = {};
    for (var c = 0; c < headers.length; c++) {
      if (headers[c]) obj[headers[c]] = fila[c];
    }
    if (obj.id) filas.push(obj);
  }
  return filas;
}


// ════════════════════════════════════════════════════════════
//  SUBIR FOTO A DRIVE → devuelve enlace de miniatura
// ════════════════════════════════════════════════════════════
function subirFoto(base64, nombre) {
  var carpeta = obtenerCarpeta();
  var partes = base64.split(',');
  var data = partes.length > 1 ? partes[1] : partes[0];
  var tipo = 'image/jpeg';
  var m = base64.match(/^data:(image\/\w+);base64,/);
  if (m) tipo = m[1];

  var blob = Utilities.newBlob(Utilities.base64Decode(data), tipo, nombre);
  var archivo = carpeta.createFile(blob);
  archivo.setSharing(DriveApp.Access.ANYONE_WITH_LINK, DriveApp.Permission.VIEW);
  var id = archivo.getId();
  return 'https://drive.google.com/thumbnail?id=' + id + '&sz=w1200';
}

function obtenerCarpeta() {
  var carpetas = DriveApp.getFoldersByName(CARPETA_FOTOS);
  if (carpetas.hasNext()) return carpetas.next();
  return DriveApp.createFolder(CARPETA_FOTOS);
}


// ════════════════════════════════════════════════════════════
//  AYUDA: respuesta JSON
// ════════════════════════════════════════════════════════════
function json(obj) {
  return ContentService
    .createTextOutput(JSON.stringify(obj))
    .setMimeType(ContentService.MimeType.JSON);
}


// ════════════════════════════════════════════════════════════
//  PRUEBA MANUAL (opcional): en el editor selecciona esta función
//  y toca ▶️ Ejecutar. Debe salir en el log el total de tus filas.
// ════════════════════════════════════════════════════════════
function testConexion() {
  var ss = SpreadsheetApp.getActiveSpreadsheet();
  Object.keys(TABLAS).forEach(function (k) {
    var h = buscarHoja(ss, TABLAS[k]);
    Logger.log(k + ' → ' + (h ? h.getName() + ': ' + Math.max(0, h.getLastRow() - 1) + ' filas' : 'NO EXISTE'));
  });
}
